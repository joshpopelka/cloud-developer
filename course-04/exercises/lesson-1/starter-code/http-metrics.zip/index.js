const AWS = require('aws-sdk')
const axios = require('axios')

// Name of a service, any string
const serviceName = process.env.SERVICE_NAME
// URL of a service to test
const url = process.env.URL

// CloudWatch client
const cloudwatch = new AWS.CloudWatch();

exports.handler = async (event) => {
  // TODO: Use these variables to record metric values
  let endTime
  let requestWasSuccessful

  const startTime = timeInMs()
  await axios.get(url)

  // Example of how to write a single data point
  let params = {
    MetricData: [
      {
        MetricName: 'Invocations', // Use different metric names for different values, e.g. 'Latency' and 'Successful'
        Dimensions: [
          {
            Name: 'exercise1',
            Value: serviceName
          }
        ],
        Unit: 'Milliseconds', // 'Count' or 'Milliseconds'
        Value: 0 // Total value
      }
    ],
    Namespace: 'Udacity/Serveless'
  };
   cloudwatch.putMetricData(params, function(err, data) {

      endTime = timeInMs();
      console.log("Time difference",endTime - startTime) 
      if (err) console.log(err, err.stack); // an error occurred
      else     console.log(data);           // successful response
    });

  // TODO: Record time it took to get a response
  

  // TODO: Record if a response was successful or not
}

function timeInMs() {
  return new Date().getTime()
}
